
const b=document.querySelector('.menu-btn'),n=document.querySelector('.nav-links');if(b&&n)b.onclick=()=>{n.classList.toggle('open');b.setAttribute('aria-expanded',n.classList.contains('open'))};
document.querySelectorAll('[data-year]').forEach(e=>e.textContent=new Date().getFullYear());
const io=new IntersectionObserver(es=>es.forEach(e=>e.isIntersecting&&e.target.classList.add('show')),{threshold:.12});document.querySelectorAll('.reveal').forEach(e=>io.observe(e));
const f=document.getElementById('whatsappForm');if(f)f.addEventListener('submit',e=>{e.preventDefault();let nome=document.getElementById('nome')?.value||'',empresa=document.getElementById('empresa')?.value||'',msg=document.getElementById('mensagem')?.value||'';window.open('https://wa.me/5531984180609?text='+encodeURIComponent(`Olá! Sou ${nome}${empresa?` da empresa ${empresa}`:''}. ${msg}`),'_blank')});
