const menuBtn=document.querySelector('.menu-btn');
const nav=document.querySelector('.nav-links');
if(menuBtn&&nav){menuBtn.addEventListener('click',()=>{const open=nav.classList.toggle('open');menuBtn.setAttribute('aria-expanded',open?'true':'false');menuBtn.textContent=open?'✕':'☰';});}
document.querySelectorAll('[data-year]').forEach(el=>el.textContent=new Date().getFullYear());
const revealObserver=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('visible');revealObserver.unobserve(entry.target);}}),{threshold:.08});
document.querySelectorAll('.reveal').forEach(el=>revealObserver.observe(el));
const form=document.querySelector('#whatsappForm,[data-whatsapp-form]');
if(form){form.addEventListener('submit',event=>{event.preventDefault();const data=new FormData(form);const nome=data.get('nome')||'';const empresa=data.get('empresa')||'';const interesse=data.get('interesse')||'';const mensagem=data.get('mensagem')||'';const parts=['Olá! Vim pelo site da Ronaldo Tech.',nome&&`Nome: ${nome}`,empresa&&`Empresa: ${empresa}`,interesse&&`Interesse: ${interesse}`,mensagem&&`Mensagem: ${mensagem}`].filter(Boolean);window.open(`https://wa.me/5531984180609?text=${encodeURIComponent(parts.join('\n'))}`,'_blank','noopener');});}
